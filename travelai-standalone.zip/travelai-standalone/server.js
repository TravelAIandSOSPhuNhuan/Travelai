// Chạy local không cần Netlify CLI:  node --env-file=.env server.js  ->  http://localhost:3000
// Cũng dùng được để deploy lên Render / Railway / VPS nếu không muốn dùng Netlify Functions.
import http from "node:http";
import { readFile } from "node:fs/promises";
import { extname, join } from "node:path";
import analyze from "./netlify/functions/analyze.js";
import narrate from "./netlify/functions/narrate.js";
import tts from "./netlify/functions/tts.js";
import ask from "./netlify/functions/ask.js";

const routes = { "/api/analyze": analyze, "/api/narrate": narrate, "/api/tts": tts, "/api/ask": ask };
const MIME = { ".html": "text/html; charset=utf-8", ".js": "text/javascript", ".css": "text/css" };
const PORT = process.env.PORT || 3000;

http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  const fn = routes[url.pathname];
  if (fn) {
    const chunks = [];
    for await (const c of req) chunks.push(c);
    const request = new Request(url, {
      method: req.method,
      headers: req.headers,
      body: ["GET", "HEAD", "OPTIONS"].includes(req.method) ? undefined : Buffer.concat(chunks),
    });
    const r = await fn(request, { ip: req.socket.remoteAddress });
    res.writeHead(r.status, Object.fromEntries(r.headers));
    return res.end(Buffer.from(await r.arrayBuffer()));
  }
  // Phục vụ file tĩnh trong /public
  const file = url.pathname === "/" ? "/index.html" : url.pathname;
  try {
    const data = await readFile(join("public", file.replace(/\.\./g, "")));
    res.writeHead(200, { "Content-Type": MIME[extname(file)] || "application/octet-stream" });
    res.end(data);
  } catch {
    res.writeHead(404).end("Not found");
  }
}).listen(PORT, () => console.log(`TravelAI server: http://localhost:${PORT}`));
