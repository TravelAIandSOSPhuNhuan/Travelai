# TravelAI 2.0 – web độc lập (Netlify + Google Gemini)

Trang `public/index.html` gọi server AI trong `netlify/functions`. Server dùng Gemini để nhận diện ảnh, tra Google Search và viết thuyết minh.

## Cấu trúc

| Thư mục / file | Vai trò |
|---|---|
| `public/index.html` | Giao diện TravelAI 2.0 |
| `netlify/functions/analyze.js` | Ảnh → nhận diện → thuyết minh |
| `netlify/functions/ask.js` | Hỏi đáp với hướng dẫn viên AI |
| `netlify/functions/narrate.js`, `tts.js` | Đổi ngôn ngữ, giọng đọc Gemini (tuỳ chọn) |
| `lib/` | Code AI dùng chung |

## Bước 1. Lấy API key Gemini

Vào https://aistudio.google.com/apikey → Create API key → copy.

## Bước 2. Deploy lên Netlify

Lưu ý: kéo thả thư mục (Netlify Drop) chỉ đưa file tĩnh lên, server AI sẽ không chạy. Chọn một trong hai cách sau.

**Cách A – qua GitHub (dễ nhất)**
1. Tạo repo mới trên GitHub, upload toàn bộ thư mục này (giữ nguyên cấu trúc).
2. Netlify → Add new site → Import an existing project → chọn repo.
3. Build command để trống, Publish directory: `public` (đã có sẵn trong `netlify.toml`).
4. Site configuration → Environment variables → thêm `GEMINI_API_KEY` = key ở bước 1.
5. Deploys → Trigger deploy. Xong.

**Cách B – qua Netlify CLI**
```bash
npm i -g netlify-cli
netlify login
netlify link            # chọn site travelaiandsos, hoặc netlify init để tạo site mới
netlify env:set GEMINI_API_KEY "key_của_bạn"
netlify deploy --prod
```

## Bước 3. Kiểm tra

Mở site → góc trên hiện **AI ACTIVE** → vào Khám phá → chụp ảnh → bấm "Chụp & Phân tích AI".
Nếu báo lỗi, xem Netlify → Logs → Functions.

## Chạy thử trên máy

```bash
cp .env.example .env    # điền GEMINI_API_KEY
npm start               # mở http://localhost:3000
```

## Ghi chú

- Nếu dùng domain khác `travelaiandsos.netlify.app`, thêm domain đó vào biến `ALLOWED_ORIGINS`.
- Trên web thật, trang xin quyền định vị để nhận diện chính xác hơn.
- Giọng đọc dùng giọng có sẵn của điện thoại/trình duyệt. Nếu máy không có giọng tiếng Việt, cài thêm trong cài đặt Text-to-Speech của điện thoại.
- API key chỉ nằm trên server, không lộ ra trình duyệt.
