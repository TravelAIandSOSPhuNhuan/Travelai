// POST /api/analyze  { imageBase64, mimeType, lang, lat?, lng?, style?: "short"|"standard", withAudio?: bool }
import { analyzePhoto } from "../../lib/gemini.js";
import { wrap } from "../../lib/http.js";

export default wrap((body) => analyzePhoto(body));
export const config = { path: "/api/analyze" };
