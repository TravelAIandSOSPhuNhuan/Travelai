// POST /api/ask  { place, context?, lang, history?: [{q,a}], question }
import { askGuide } from "../../lib/gemini.js";
import { wrap } from "../../lib/http.js";

export default wrap((body) => askGuide(body));
export const config = { path: "/api/ask" };
