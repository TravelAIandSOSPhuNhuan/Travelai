// POST /api/narrate  { name, city?, country?, lang, style? }
// Dùng khi người dùng đổi ngôn ngữ hoặc gõ tên địa điểm (không cần chụp lại ảnh)
import { narrate, HttpError } from "../../lib/gemini.js";
import { wrap } from "../../lib/http.js";

export default wrap(async ({ name, city, country, lang = "vi", style }) => {
  if (!name) throw new HttpError(400, "Thiếu tên địa điểm (name)");
  return { ok: true, guide: await narrate({ landmark: { name, city, country }, lang, style }) };
});
export const config = { path: "/api/narrate" };
