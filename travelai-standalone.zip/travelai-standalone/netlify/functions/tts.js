// POST /api/tts  { text, lang }  -> { ok, mimeType: "audio/wav", base64 }
import { textToSpeech, HttpError } from "../../lib/gemini.js";
import { wrap } from "../../lib/http.js";

export default wrap(async ({ text, lang = "vi" }) => {
  if (!text) throw new HttpError(400, "Thiếu text");
  if (text.length > 3000) throw new HttpError(413, "Văn bản quá dài");
  return { ok: true, mimeType: "audio/wav", base64: await textToSpeech({ text, lang }) };
});
export const config = { path: "/api/tts" };
